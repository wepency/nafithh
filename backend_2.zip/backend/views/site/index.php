<?php
use common\models\Setting;
use yii\helpers\ArrayHelper;
use yii\helpers\StringHelper; 


/* @var $this yii\web\View */

 ?>

    <div class="content">
     
        <div class="site-index" style="margin-bottom: : 150px;min-height: 770px;">
        </div>
    </div>
<!-- Bootstrap 3.3.7 -->

<!-- AdminLTE App -->
<!-- AdminLTE for demo purposes -->
<!-- page script -->

